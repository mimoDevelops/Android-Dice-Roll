package com.st991664700.geoquizch2byjoshuafaria

import androidx.annotation.StringRes

data class Question(@StringRes val textResId: Int, val answer: Boolean)